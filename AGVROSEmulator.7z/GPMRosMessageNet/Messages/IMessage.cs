﻿namespace AGVROSEmulator.GPMRosMessageNet.Messages
{
    public interface IMessage
    {
        string RosMessageName { get; set; }
    }
}
